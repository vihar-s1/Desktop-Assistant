// window is an API
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
const recognition = new SpeechRecognition();

window.onload = () => {
  recognition.start();

  recognition.onresult = (event) => {
    const command = event.results[0][0].transcript;

    if (command === "go up" || command === "scroll up") {
      window.scrollBy(0, -100);
    } else if (command === "go down" || command === "scroll down") {
      window.scrollBy(0, 100);
    } else if (command === "go to half") {
      window.scrollTo(0, document.body.scrollHeight / 2);
    } else if (command === "go to top" || command === "go top") {
      window.scrollTo(0, 0);
    } else if (command === "go to bottom" || command === "go bottom") {
      const maxScroll =
        document.documentElement.scrollHeight - document.documentElement.clientHeight;
      window.scrollTo(0, maxScroll);
    } else if (command === "scroll left") {
      window.scrollBy(-100, 0);
    } else if (command === "scroll right") {
      window.scrollBy(100, 0);
    }
  };
};

recognition.onend = () => {
  recognition.start();
};

console.log(recognition);
